#pragma once
#include "Actor.h"
class SphereActor : public Actor
{
public:
	SphereActor();
};

